# Analise Multivariada E Aprendizado Nao Supervisionado

Aulas e comandos em R e Python do curso SME0822 Análise Multivariada e Aprendizado Não-Supervisionado.

Por Cibele Russo - ICMC USP
